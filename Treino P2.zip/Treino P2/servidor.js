require("colors")

var express = require("express");
var bodyParser = require("body-parser");

var app = express();

app.use(express.static("./public"));
app.use(bodyParser.urlencoded({ extended: false }));

app.set("view engine", "ejs");
app.set("views", "./views");

app.listen(80);

console.log("Servidor rodando...".yellow);

// =======================
// DADOS EM MEMÓRIA
// =======================

var usuarios = [];
var produtos = [];

// =======================
// HOME
// =======================

app.get("/", function(req, res){
    res.sendFile(__dirname + "/public/index.html");
});

// =======================
// CADASTRAR USUÁRIO
// =======================

app.post("/cadastrarUsuario", function(req, res){

    if(usuarios.length >= 10){
        return res.send("Limite de usuários atingido!");
    }

    usuarios.push({
        nome: req.body.nome,
        cpf: req.body.cpf
    });

    console.log("USUÁRIOS:", usuarios);

    res.redirect("/usuarios");
});

// =======================
// CADASTRAR PRODUTO
// =======================

app.post("/cadastrarProduto", function(req, res){

    if(produtos.length >= 10){
        return res.send("Limite de produtos atingido!");
    }

    produtos.push({
        nome: req.body.nome,
        preco: req.body.preco
    });

    console.log("PRODUTOS:", produtos);

    res.redirect("/produtos");
});

// =======================
// LISTAR USUÁRIOS
// =======================

app.get("/usuarios", function(req, res){
    res.render("usuarios.ejs", {
        usuarios: usuarios
    });
});

// =======================
// LISTAR PRODUTOS
// =======================

app.get("/produtos", function(req, res){
    res.render("produtos.ejs", {
        produtos: produtos
    });
});
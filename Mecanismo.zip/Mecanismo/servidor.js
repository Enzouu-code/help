require("colors");

var http = require("http");
var express = require("express");
var bodyParser = require("body-parser");
var mongodb = require("mongodb");

const MongoClient = mongodb.MongoClient;
const ObjectId = mongodb.ObjectId;

// MongoDB URI
const uri = "mongodb://enzo:Enzo210807@ac-lkx8xoy-shard-00-00.jltwsky.mongodb.net:27017,ac-lkx8xoy-shard-00-01.jltwsky.mongodb.net:27017,ac-lkx8xoy-shard-00-02.jltwsky.mongodb.net:27017/?ssl=true&replicaSet=atlas-evx3kv-shard-0&authSource=admin&appName=Cluster0";

const client = new MongoClient(uri);

var app = express();

// arquivos estáticos (CSS, HTML)
app.use(express.static("./public"));

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// EJS
app.set("view engine", "ejs");
app.set("views", "./views");

// servidor na porta 80
var server = http.createServer(app);

server.listen(80, function () {
    console.log("Servidor rodando na porta 80".rainbow);
});

// ======================
// CONEXÃO MONGODB
// ======================

console.log("Tentando conectar ao MongoDB...".yellow);

client.connect()
.then(function () {

    console.log("MongoDB conectado!".green);

    var dbo = client.db("exemplo_bd");
    var usuarios = dbo.collection("usuarios");

    // ======================
    // ROTA HOME (CADASTRO)
    // ======================

    app.get("/", function (req, res) {
        res.sendFile(__dirname + "/public/cadastro.html");
    });

    // ======================
    // LOGIN PAGE
    // ======================

    app.get("/login", function (req, res) {
        res.sendFile(__dirname + "/public/login.html");
    });

    // ======================
    // CADASTRAR USUÁRIO
    // ======================

    app.post("/cadastrar_usuario", function (req, res) {

        var data = {
            db_nome: req.body.nome,
            db_login: req.body.login,
            db_senha: req.body.senha
        };

        console.log("NOVO CADASTRO:");
        console.log(data);

        usuarios.insertOne(data)
        .then(function () {

            console.log("Usuário cadastrado!".green);

            res.render("resposta", {
                resposta: "Usuário cadastrado com sucesso!"
            });

        })
        .catch(function (err) {

            console.log(err);

            res.render("resposta", {
                resposta: "Erro ao cadastrar usuário!"
            });

        });

    });

    // ======================
    // LOGIN USUÁRIO
    // ======================

    app.post("/logar_usuario", function (req, res) {

        usuarios.findOne({
            db_login: req.body.login,
            db_senha: req.body.senha
        })
        .then(function (user) {

            if (!user) {

                res.render("resposta", {
                    resposta: "Usuário ou senha inválidos!"
                });

            } else {

                console.log("LOGIN REALIZADO!".green);

                res.render("resposta", {
                    resposta: "Login realizado com sucesso!"
                });

            }

        })
        .catch(function (err) {

            console.log(err);

            res.render("resposta", {
                resposta: "Erro no login!"
            });

        });

    });

})
.catch(function (err) {
    console.log("ERRO AO CONECTAR NO MONGODB".red);
    console.log(err);
});
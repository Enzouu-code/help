require("colors");

var http = require("http");
var express = require("express");
var bodyParser = require("body-parser");
var mongodb = require("mongodb");

const MongoClient = mongodb.MongoClient;
const ObjectId = mongodb.ObjectId;

// SUA URI
const uri = "mongodb://enzo:Enzo210807@ac-lkx8xoy-shard-00-00.jltwsky.mongodb.net:27017,ac-lkx8xoy-shard-00-01.jltwsky.mongodb.net:27017,ac-lkx8xoy-shard-00-02.jltwsky.mongodb.net:27017/?ssl=true&replicaSet=atlas-evx3kv-shard-0&authSource=admin&appName=Cluster0";

const client = new MongoClient(uri);

var app = express();

app.use(express.static("./public"));

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.set("view engine", "ejs");
app.set("views", "./views");

var server = http.createServer(app);

server.listen(80);

console.log("Servidor rodando na porta 80...".rainbow);

console.log("Tentando conectar ao MongoDB...".yellow);

client.connect()

.then(function() {

    console.log("MongoDB conectado!".green);

    var dbo = client.db("exemplo_bd");

    var usuarios = dbo.collection("usuarios");

    // =========================
    // PÁGINA INICIAL
    // =========================

    app.get("/", function(req, res){

        res.sendFile(__dirname + "/public/index.html");

    });

    // =========================
    // CADASTRO
    // =========================

    app.post("/cadastrar", async function(req, res){

        var dados = {
            nome: req.body.nome,
            idade: req.body.idade,
            cpf: req.body.cpf,
            senha: req.body.senha
        };

        await usuarios.insertOne(dados);

        console.log("USUÁRIO CADASTRADO:".green);
        console.log(dados);

        res.render("resposta.ejs", {
            mensagem: "Usuário cadastrado com sucesso!"
        });

    });

    // =========================
    // LOGIN
    // =========================

    app.post("/login", async function(req, res){

        var usuario = await usuarios.findOne({
            nome: req.body.nome,
            senha: req.body.senha
        });

        if(usuario){

            console.log("LOGIN REALIZADO:".cyan);
            console.log(usuario);

            res.render("resposta.ejs", {
                mensagem: "Login realizado com sucesso!"
            });

        } else {

            res.render("resposta.ejs", {
                mensagem: "Usuário não encontrado!"
            });

        }

    });

    // =========================
    // ATUALIZAR
    // =========================

    app.post("/atualizar", async function(req, res){

        await usuarios.updateOne(

            { cpf: req.body.cpf },

            {
                $set: {
                    nome: req.body.nome,
                    idade: req.body.idade
                }
            }

        );

        console.log("USUÁRIO ATUALIZADO".blue);

        res.render("resposta.ejs", {
            mensagem: "Usuário atualizado!"
        });

    });

    // =========================
    // DELETAR
    // =========================

    app.post("/deletar", async function(req, res){

        await usuarios.deleteOne({
            cpf: req.body.cpf
        });

        console.log("USUÁRIO DELETADO".red);

        res.render("resposta.ejs", {
            mensagem: "Usuário deletado!"
        });

    });

})

.catch(function(err) {

    console.log("ERRO AO CONECTAR NO MONGODB:".red);

    console.log(err.message);

});